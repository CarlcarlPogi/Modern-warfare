# MW Extras - TaCZ addon (Forge 1.20.1)

Adds to a TaCZ (Timeless and Classics Zero) setup:

* **Throwing Knife** - 3D tactical knife model (blackened blade, bright ground edge, fuller, diamond-cut grip).
  Right click to throw. It tumbles end-over-end, sticks into blocks, can be picked back up, headshots hit harder.
* **Armor Plate** - hold right click: vest *unzips* -> plate slides in -> vest *zips*. Max 3 plates (configurable).
* **Plate bar HUD** - sits directly under the hearts. Each plate that breaks flashes, cracks and shatters into falling shards.
* **Plates break when shot** - each TaCZ bullet hit destroys one plate and soaks up to `plateAbsorb` damage of that hit.
  Plates are lost on death, kept across relog/dimension change.
* Recipes: knife = 2 iron ingots over 1 stick (x2). Plate = 6 iron ingots + 1 leather (ring shape).

## Build
1. Install JDK 17.
2. Easiest: download the official **Forge 1.20.1 MDK** (forge 47.3.0) from files.minecraftforge.net, copy its
   `gradlew`, `gradlew.bat` and `gradle/` folder into this directory (the wrapper jar can't ship in this zip).
3. `./gradlew build`  ->  `build/libs/mwextras-1.0.0.jar` -> drop into `mods/` together with TaCZ.
   (or `./gradlew runClient` to test in a dev environment.)

## Config  (`config/mwextras-common.toml`)
| key | default | what |
|---|---|---|
| maxPlates | 3 | plate slots / HUD segments |
| plateAbsorb | 12.0 | damage ONE plate soaks per hit (set 1000 = plate eats the whole shot) |
| plateUseTicks | 50 | time to apply a plate |
| absorbAnyProjectile | false | also break plates on arrows / other-mod projectiles |
| knifeDamage | 14.0 | thrown knife damage |
| knifeHeadshotMultiplier | 1.5 | multiplier at head height |
| knifeSpeed | 2.8 | throw velocity |
| knifeCooldownTicks | 8 | delay between throws |

## Re-generating / tweaking assets
`python3 tools/generate_assets.py` rebuilds textures, 3D models and all sounds
(needs numpy, scipy, Pillow, ffmpeg). Edit the script to change colours, blade shape or the SFX.
All assets are original/procedural.

## TaCZ detection
Bullets are recognised without linking to TaCZ: the damage source's direct entity or damage type must be in the
`tacz` namespace (or the damage id contains "bullet"). If a TaCZ update changes that, turn on `absorbAnyProjectile`.
