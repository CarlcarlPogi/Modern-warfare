package dev.mwextras;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MWExtras.MODID);

    public static final RegistryObject<SoundEvent> UNZIP  = reg("item.plate.unzip");
    public static final RegistryObject<SoundEvent> ZIP    = reg("item.plate.zip");
    public static final RegistryObject<SoundEvent> INSERT = reg("item.plate.insert");
    public static final RegistryObject<SoundEvent> PLATE_BREAK = reg("item.plate.break");
    public static final RegistryObject<SoundEvent> KNIFE_THROW = reg("item.knife.throw");
    public static final RegistryObject<SoundEvent> KNIFE_STICK = reg("item.knife.stick");
    public static final RegistryObject<SoundEvent> KNIFE_HIT   = reg("item.knife.hit");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(MWExtras.MODID, name)));
    }
}
