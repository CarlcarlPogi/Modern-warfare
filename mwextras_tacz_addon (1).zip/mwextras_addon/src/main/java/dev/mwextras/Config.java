package dev.mwextras;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue MAX_PLATES = B
            .comment("How many plate slots the HUD bar has / how many plates a player can wear.")
            .defineInRange("maxPlates", 3, 1, 6);

    public static final ForgeConfigSpec.DoubleValue PLATE_ABSORB = B
            .comment("Max damage ONE plate soaks from a single hit before it is destroyed.",
                     "Anything above this goes through to the player. Set very high (e.g. 1000) for 'a plate always eats the whole shot'.")
            .defineInRange("plateAbsorb", 12.0, 0.0, 1000.0);

    public static final ForgeConfigSpec.IntValue PLATE_USE_TICKS = B
            .comment("How long applying one plate takes, in ticks (20 = 1 second).")
            .defineInRange("plateUseTicks", 50, 10, 200);

    public static final ForgeConfigSpec.BooleanValue ANY_PROJECTILE = B
            .comment("Also let plates break from vanilla/other-mod projectiles (arrows, tridents, ...). TaCZ bullets always count.")
            .define("absorbAnyProjectile", false);

    public static final ForgeConfigSpec.DoubleValue KNIFE_DAMAGE = B
            .comment("Damage of a thrown knife (2 = 1 heart).")
            .defineInRange("knifeDamage", 14.0, 1.0, 100.0);

    public static final ForgeConfigSpec.DoubleValue KNIFE_HEAD_MULT = B
            .comment("Damage multiplier when the knife hits at head height.")
            .defineInRange("knifeHeadshotMultiplier", 1.5, 1.0, 10.0);

    public static final ForgeConfigSpec.DoubleValue KNIFE_SPEED = B
            .comment("Throw velocity. Higher = flatter, faster flight.")
            .defineInRange("knifeSpeed", 2.8, 0.5, 6.0);

    public static final ForgeConfigSpec.IntValue KNIFE_COOLDOWN = B
            .comment("Ticks between knife throws.")
            .defineInRange("knifeCooldownTicks", 8, 0, 100);

    public static final ForgeConfigSpec SPEC = B.build();
}
