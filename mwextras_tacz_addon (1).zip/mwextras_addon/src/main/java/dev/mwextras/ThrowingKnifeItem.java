package dev.mwextras;

import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ThrowingKnifeItem extends Item {

    public ThrowingKnifeItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY() + 1.4, player.getZ(),
                ModSounds.KNIFE_THROW.get(), SoundSource.PLAYERS,
                0.8F, 0.92F + level.getRandom().nextFloat() * 0.16F);

        if (!level.isClientSide) {
            ThrownKnife knife = new ThrownKnife(level, player);
            knife.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F,
                    Config.KNIFE_SPEED.get().floatValue(), 0.4F);
            if (player.getAbilities().instabuild) {
                knife.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
            }
            level.addFreshEntity(knife);
        }

        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) stack.shrink(1);
        player.getCooldowns().addCooldown(this, Config.KNIFE_COOLDOWN.get());
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
