package dev.mwextras.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dev.mwextras.Config;
import dev.mwextras.ModItems;
import dev.mwextras.PlateClientCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Warzone-style plate bar, drawn in the row directly under the hearts.
 * Everything is drawn with fills, so there are no extra HUD textures to maintain.
 */
public class PlateHud {

    private static final int SEG_W = 26, SEG_H = 6, GAP = 2;
    private static final float FX_LIFE = 18.0F; // ticks

    private record Shard(float x, float y, float vx, float vy, int size, int color) {}

    private static class Fx {
        final int slot;
        final float start;
        final List<Shard> shards = new ArrayList<>();
        Fx(int slot, float start) { this.slot = slot; this.start = start; }
    }

    private static final List<Fx> FX = new ArrayList<>();
    private static final RandomSource RNG = RandomSource.create();

    /** Called from PlatePacket on the client thread. */
    public static void onPacket(int plates, int broken) {
        PlateClientCache.plates = plates;
        if (broken < 0) return;

        Minecraft mc = Minecraft.getInstance();
        Fx fx = new Fx(broken, mc.level != null ? mc.level.getGameTime() : 0);
        int[] palette = { 0xFFB9C7D6, 0xFF8FA3B5, 0xFF5E7183, 0xFFE8F0F7 };
        for (int i = 0; i < 14; i++) {
            fx.shards.add(new Shard(
                    RNG.nextFloat() * SEG_W, RNG.nextFloat() * SEG_H,
                    (RNG.nextFloat() - 0.5F) * 2.6F, -1.4F + RNG.nextFloat() * 1.2F,
                    1 + RNG.nextInt(2), palette[RNG.nextInt(palette.length)]));
        }
        FX.add(fx);
    }

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> {
        Minecraft mc = gui.getMinecraft();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.options.hideGui || !mc.gameMode.canHurtPlayer()) return;

        int max = Config.MAX_PLATES.get();
        int plates = Mth.clamp(PlateClientCache.plates, 0, max);

        int x0 = width / 2 - 91;
        int y0 = height - gui.leftHeight + 2;     // row right under the hearts
        gui.leftHeight += SEG_H + 4;              // pushes hearts/armor up to make room

        float now = mc.level.getGameTime() + partialTick;

        // 1. empty backing for every slot
        for (int i = 0; i < max; i++) {
            int x = x0 + i * (SEG_W + GAP);
            chamfer(g, x - 1, y0 - 1, SEG_W + 2, SEG_H + 2, 0xFF07090B);
            chamfer(g, x, y0, SEG_W, SEG_H, 0xC0242A30);
        }

        // 2. filled plates
        for (int i = 0; i < plates; i++) {
            drawPlate(g, x0 + i * (SEG_W + GAP), y0, SEG_W);
        }

        // 3. plate currently being applied: fills left -> right with a pulse
        if (plates < max && player.isUsingItem() && player.getUseItem().is(ModItems.ARMOR_PLATE.get())) {
            float total = Config.PLATE_USE_TICKS.get();
            float prog = Mth.clamp((total - player.getUseItemRemainingTicks() + partialTick) / total, 0, 1);
            int x = x0 + plates * (SEG_W + GAP);
            int w = Math.max(1, (int) (SEG_W * prog));
            int pulse = 0x90 + (int) (0x50 * Mth.sin(now * 0.6F));
            g.fill(x, y0, x + w, y0 + SEG_H, 0xFF000000 | (0x4F << 16) | (0x93 << 8) | (pulse & 0xFF));
            g.fill(x, y0, x + w, y0 + 1, 0xFFBFE0FF);
        }

        // 4. break effects: white flash -> crack -> shards fall
        Iterator<Fx> it = FX.iterator();
        while (it.hasNext()) {
            Fx fx = it.next();
            float age = now - fx.start;
            if (age > FX_LIFE || age < 0) { it.remove(); continue; }

            int x = x0 + fx.slot * (SEG_W + GAP);
            if (age < 3.0F) {
                chamfer(g, x, y0, SEG_W, SEG_H, 0xFFFFFFFF);
            } else if (age < 6.0F) {
                chamfer(g, x, y0, SEG_W, SEG_H, 0xFF6C7D8E);
                int cx = x + SEG_W / 2;
                g.fill(cx - 1, y0, cx, y0 + 2, 0xFF050607);
                g.fill(cx, y0 + 2, cx + 1, y0 + 4, 0xFF050607);
                g.fill(cx - 2, y0 + 4, cx - 1, y0 + SEG_H, 0xFF050607);
            }
            float t = Math.max(0.0F, age - 3.0F);
            int alpha = (int) (255 * Mth.clamp(1.0F - t / (FX_LIFE - 3.0F), 0.0F, 1.0F));
            for (Shard s : fx.shards) {
                int px = x + (int) (s.x() + s.vx() * t);
                int py = y0 + (int) (s.y() + s.vy() * t + 0.32F * t * t);
                int col = (alpha << 24) | (s.color() & 0xFFFFFF);
                g.fill(px, py, px + s.size(), py + s.size(), col);
            }
        }
    };

    private static void drawPlate(GuiGraphics g, int x, int y, int w) {
        chamfer(g, x, y, w, SEG_H, 0xFF8FA3B5);
        g.fill(x + 1, y, x + w - 1, y + 1, 0xFFD5E1EC);              // top highlight
        g.fill(x + 1, y + SEG_H - 1, x + w - 1, y + SEG_H, 0xFF5E7183); // bottom shade
        for (int px = x + 4; px < x + w - 2; px += 4) {               // ceramic hex-ish ticks
            g.fill(px, y + 2, px + 1, y + SEG_H - 2, 0x26FFFFFF);
        }
    }

    /** Rectangle with the corner pixels cut, to read as a plate shape. */
    private static void chamfer(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x + 1, y, x + w - 1, y + h, color);
        g.fill(x, y + 1, x + w, y + h - 1, color);
    }
}
