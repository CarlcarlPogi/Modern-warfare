package dev.mwextras.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import dev.mwextras.ModItems;
import dev.mwextras.ThrownKnife;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws the real 3D knife item model, pointed along the flight path and tumbling end-over-end. */
public class ThrownKnifeRenderer extends EntityRenderer<ThrownKnife> {
    private final ItemStack stack = new ItemStack(ModItems.THROWING_KNIFE.get());
    private final net.minecraft.client.renderer.entity.ItemRenderer itemRenderer;

    public ThrownKnifeRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
    }

    @Override
    public void render(ThrownKnife knife, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        pose.pushPose();

        // same orientation basis the vanilla arrow uses: +X = direction of travel
        pose.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTick, knife.yRotO, knife.getYRot()) - 90.0F));
        pose.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTick, knife.xRotO, knife.getXRot())));

        // The model has its blade along +Y, so -90 on Z lines the tip up with +X.
        float spin = knife.isStuck() ? 0.0F : -(knife.tickCount + partialTick) * 52.0F;
        pose.mulPose(Axis.ZP.rotationDegrees(-90.0F + spin));

        float s = 1.15F;
        pose.scale(s, s, s);

        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY,
                pose, buffers, knife.level(), knife.getId());

        pose.popPose();
        super.render(knife, yaw, partialTick, pose, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ThrownKnife knife) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
