package dev.mwextras;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/** Plates are stored in the player's persistent NBT (survives relog) and synced to the client. */
public class PlateData {
    private static final String KEY = "mwextras_plates";

    public static int get(Player p) {
        if (p.level().isClientSide) return PlateClientCache.plates;
        return p.getPersistentData().getInt(KEY);
    }

    public static void set(ServerPlayer p, int value) {
        p.getPersistentData().putInt(KEY, Mth.clamp(value, 0, Config.MAX_PLATES.get()));
    }

    public static void sync(ServerPlayer p) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new PlatePacket(get(p), -1));
    }
}
